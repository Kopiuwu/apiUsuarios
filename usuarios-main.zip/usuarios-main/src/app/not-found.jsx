import "@/app/not-found.css"
export default function NoFound(){
    return(
        <div className="centrar">
            <h1>Error 404</h1>
            <p>Pagina no encontrada lol</p>
        </div>
    );
}