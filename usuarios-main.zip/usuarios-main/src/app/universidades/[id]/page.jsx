export default function Universidad({params}){
    return(
        <>
            <h1>Estas en Universidad lol</h1>
            <p>{params.id}</p>
        </>
    )
}